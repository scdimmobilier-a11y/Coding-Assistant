"""Human feedback decorator for Flow methods.

This module provides the @human_feedback decorator that enables human-in-the-loop
workflows within CrewAI Flows. It allows collecting human feedback on method outputs
and optionally routing to different listeners based on the feedback.

Supports both synchronous (blocking) and asynchronous (non-blocking) feedback
collection through the provider parameter.

Example (synchronous, default):
    ```python
    from crewai.flow import Flow, start, listen, human_feedback


    class ReviewFlow(Flow):
        @start()
        @human_feedback(
            message="Please review this content:",
            emit=["approved", "rejected"],
            llm="gpt-4o-mini",
        )
        def generate_content(self):
            return {"title": "Article", "body": "Content..."}

        @listen("approved")
        def publish(self):
            result = self.human_feedback
            print(f"Publishing: {result.output}")
    ```

Example (asynchronous with custom provider):
    ```python
    from crewai.flow import Flow, start, human_feedback
    from crewai.flow.async_feedback import HumanFeedbackProvider, HumanFeedbackPending


    class SlackProvider(HumanFeedbackProvider):
        def request_feedback(self, context, flow):
            self.send_notification(context)
            raise HumanFeedbackPending(context=context)


    class ReviewFlow(Flow):
        @start()
        @human_feedback(
            message="Review this:",
            emit=["approved", "rejected"],
            llm="gpt-4o-mini",
            provider=SlackProvider(),
        )
        def generate_content(self):
            return "Content..."
    ```
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from functools import wraps
import logging
from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel, Field

from crewai.flow.flow_wrappers import FlowMethod


if TYPE_CHECKING:
    from crewai.flow.async_feedback.types import HumanFeedbackProvider
    from crewai.flow.flow import Flow
    from crewai.llms.base_llm import BaseLLM


logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

__all__ = ["HumanFeedbackResult", "human_feedback"]


def _serialize_llm_for_context(llm: Any) -> dict[str, Any] | str | None:
    to_config: Callable[[], dict[str, Any]] | None = getattr(
        llm, "to_config_dict", None
    )
    if to_config is not None:
        return to_config()

    # Fallback for non-BaseLLM objects: just extract model + provider prefix
    model = getattr(llm, "model", None)
    if not model:
        return None
    provider = getattr(llm, "provider", None)
    return f"{provider}/{model}" if provider and "/" not in model else model


def _deserialize_llm_from_context(
    llm_data: dict[str, Any] | str | None,
) -> BaseLLM | None:
    if llm_data is None:
        return None

    from crewai.llm import LLM

    if isinstance(llm_data, str):
        return LLM(model=llm_data)

    if isinstance(llm_data, dict):
        data = dict(llm_data)
        model = data.pop("model", None)
        if not model:
            return None
        return LLM(model=model, **data)
    return None


@dataclass
class HumanFeedbackResult:
    """Result from a @human_feedback decorated method.

    This dataclass captures all information about a human feedback interaction,
    including the original method output, the human's feedback, and any
    collapsed outcome for routing purposes.

    Attributes:
        output: The original return value from the decorated method that was
            shown to the human for review.
        feedback: The raw text feedback provided by the human. Empty string
            if no feedback was provided.
        outcome: The collapsed outcome string when emit is specified.
            This is determined by the LLM based on the human's feedback.
            None if emit was not specified.
        timestamp: When the feedback was received.
        method_name: The name of the decorated method that triggered feedback.
        metadata: Optional metadata for enterprise integrations. Can be used
            to pass additional context like channel, assignee, etc.

    Example:
        ```python
        @listen("approved")
        def handle_approval(self):
            result = self.human_feedback
            print(f"Output: {result.output}")
            print(f"Feedback: {result.feedback}")
            print(f"Outcome: {result.outcome}")  # "approved"
        ```
    """

    output: Any
    feedback: str
    outcome: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)
    method_name: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class HumanFeedbackConfig:
    """Configuration for the @human_feedback decorator.

    Stores the parameters passed to the decorator for later use during
    method execution and for introspection by visualization tools.

    Attributes:
        message: The message shown to the human when requesting feedback.
        emit: Optional sequence of outcome strings for routing.
        llm: The LLM model to use for collapsing feedback to outcomes.
        default_outcome: The outcome to use when no feedback is provided.
        metadata: Optional metadata for enterprise integrations.
        provider: Optional custom feedback provider for async workflows.
    """

    message: str
    emit: Sequence[str] | None = None
    llm: str | BaseLLM | None = "gpt-4o-mini"
    default_outcome: str | None = None
    metadata: dict[str, Any] | None = None
    provider: HumanFeedbackProvider | None = None
    learn: bool = False
    learn_source: str = "hitl"
    learn_strict: bool = False


class HumanFeedbackMethod(FlowMethod[Any, Any]):
    """Wrapper for methods decorated with @human_feedback.

    This wrapper extends FlowMethod to add human feedback specific attributes
    that are used by FlowMeta for routing and by visualization tools.

    Attributes:
        __is_router__: True when emit is specified, enabling router behavior.
        __router_emit__: List of possible outcomes when acting as a router.
        __human_feedback_config__: The HumanFeedbackConfig for this method.
    """

    __is_router__: bool = False
    __router_emit__: list[str] | None = None
    __human_feedback_config__: HumanFeedbackConfig | None = None


class PreReviewResult(BaseModel):
    """Structured output from the HITL pre-review LLM call."""

    improved_output: str = Field(
        description="The improved version of the output with past human feedback lessons applied.",
    )


class DistilledLessons(BaseModel):
    """Structured output from the HITL lesson distillation LLM call."""

    lessons: list[str] = Field(
        default_factory=list,
        description=(
            "Generalizable lessons extracted from the human feedback. "
            "Each lesson should be a reusable rule or preference. "
            "Return an empty list if the feedback contains no generalizable guidance."
        ),
    )


def _build_human_feedback_runtime_decorator(
    message: str,
    emit: Sequence[str] | None = None,
    llm: str | BaseLLM | None = "gpt-4o-mini",
    default_outcome: str | None = None,
    metadata: dict[str, Any] | None = None,
    provider: HumanFeedbackProvider | None = None,
    learn: bool = False,
    learn_source: str = "hitl",
    learn_strict: bool = False,
) -> Callable[[F], F]:
    if emit is not None:
        if not llm:
            raise ValueError(
                "llm is required when emit is specified. "
                "Provide an LLM model string (e.g., 'gpt-4o-mini') or a BaseLLM instance. "
                "See the CrewAI Human-in-the-Loop (HITL) documentation for more information: "
                "https://docs.crewai.com/en/learn/human-feedback-in-flows"
            )
        if default_outcome is not None and default_outcome not in emit:
            raise ValueError(
                f"default_outcome '{default_outcome}' must be one of the "
                f"emit options: {list(emit)}"
            )
    elif default_outcome is not None:
        raise ValueError("default_outcome requires emit to be specified.")

    def decorator(func: F) -> F:
        def _get_hitl_prompt(key: str) -> str:
            from crewai.utilities.i18n import I18N_DEFAULT

            return I18N_DEFAULT.slice(key)

        def _resolve_llm_instance() -> Any:
            if llm is None:
                from crewai.llm import LLM

                return LLM(model="gpt-4o-mini")
            if isinstance(llm, str):
                from crewai.llm import LLM

                return LLM(model=llm)
            return llm  # already a BaseLLM instance

        def _pre_review_with_lessons(
            flow_instance: Flow[Any], method_output: Any
        ) -> Any:
            try:
                mem = flow_instance.memory
                if mem is None:
                    return method_output
                query = f"human feedback lessons for {func.__name__}: {method_output!s}"
                matches = mem.recall(query, source=learn_source)
                if not matches:
                    return method_output

                lessons = "\n".join(f"- {m.record.content}" for m in matches)
                llm_inst = _resolve_llm_instance()
                prompt = _get_hitl_prompt("hitl_pre_review_user").format(
                    output=str(method_output),
                    lessons=lessons,
                )
                messages = [
                    {
                        "role": "system",
                        "content": _get_hitl_prompt("hitl_pre_review_system"),
                    },
                    {"role": "user", "content": prompt},
                ]
                if getattr(llm_inst, "supports_function_calling", lambda: False)():
                    response = llm_inst.call(messages, response_model=PreReviewResult)
                    if isinstance(response, PreReviewResult):
                        return response.improved_output
                    return PreReviewResult.model_validate(response).improved_output
                reviewed = llm_inst.call(messages)
                return reviewed if isinstance(reviewed, str) else str(reviewed)
            except Exception:
                if learn_strict:
                    logger.warning(
                        "HITL pre-review failed for %s; re-raising (learn_strict=True)",
                        func.__name__,
                        exc_info=True,
                    )
                    raise
                logger.warning(
                    "HITL pre-review failed for %s; falling back to raw output",
                    func.__name__,
                    exc_info=True,
                )
                return method_output

        def _distill_and_store_lessons(
            flow_instance: Flow[Any], method_output: Any, raw_feedback: str
        ) -> None:
            try:
                mem = flow_instance.memory
                if mem is None:
                    return
                llm_inst = _resolve_llm_instance()
                prompt = _get_hitl_prompt("hitl_distill_user").format(
                    method_name=func.__name__,
                    output=str(method_output),
                    feedback=raw_feedback,
                )
                messages = [
                    {
                        "role": "system",
                        "content": _get_hitl_prompt("hitl_distill_system"),
                    },
                    {"role": "user", "content": prompt},
                ]

                lessons: list[str] = []
                if getattr(llm_inst, "supports_function_calling", lambda: False)():
                    response = llm_inst.call(messages, response_model=DistilledLessons)
                    if isinstance(response, DistilledLessons):
                        lessons = response.lessons
                    else:
                        lessons = DistilledLessons.model_validate(response).lessons
                else:
                    response = llm_inst.call(messages)
                    if isinstance(response, str):
                        lessons = [
                            line.strip("- ").strip()
                            for line in response.strip().split("\n")
                            if line.strip() and line.strip() != "NONE"
                        ]

                if lessons:
                    mem.remember_many(lessons, source=learn_source)  # type: ignore[union-attr]
            except Exception:
                if learn_strict:
                    logger.warning(
                        "HITL lesson distillation failed for %s; re-raising (learn_strict=True)",
                        func.__name__,
                        exc_info=True,
                    )
                    raise
                logger.warning(
                    "HITL lesson distillation failed for %s; no lessons stored",
                    func.__name__,
                    exc_info=True,
                )

        def _build_feedback_context(
            flow_instance: Flow[Any], method_output: Any
        ) -> tuple[Any, Any]:
            from crewai.flow.async_feedback.types import PendingFeedbackContext

            context = PendingFeedbackContext(
                flow_id=flow_instance.flow_id or "unknown",
                flow_class=f"{flow_instance.__class__.__module__}.{flow_instance.__class__.__name__}",
                method_name=func.__name__,
                method_output=method_output,
                message=message,
                emit=list(emit) if emit else None,
                default_outcome=default_outcome,
                metadata=metadata or {},
                llm=llm if isinstance(llm, str) else _serialize_llm_for_context(llm),
            )

            effective_provider = provider
            if effective_provider is None:
                from crewai.flow.flow_config import flow_config

                effective_provider = flow_config.hitl_provider

            return context, effective_provider

        def _request_feedback(flow_instance: Flow[Any], method_output: Any) -> str:
            context, effective_provider = _build_feedback_context(
                flow_instance, method_output
            )

            if effective_provider is not None:
                feedback_result = effective_provider.request_feedback(
                    context, flow_instance
                )
                if asyncio.iscoroutine(feedback_result):
                    raise TypeError(
                        f"Provider {type(effective_provider).__name__}.request_feedback() "
                        "returned a coroutine in a sync flow method. Use an async flow "
                        "method or a synchronous provider."
                    )
                return str(feedback_result)
            return flow_instance._request_human_feedback(
                message=message,
                output=method_output,
                metadata=metadata,
                emit=emit,
            )

        async def _request_feedback_async(
            flow_instance: Flow[Any], method_output: Any
        ) -> str:
            context, effective_provider = _build_feedback_context(
                flow_instance, method_output
            )

            if effective_provider is not None:
                feedback_result = effective_provider.request_feedback(
                    context, flow_instance
                )
                if asyncio.iscoroutine(feedback_result):
                    return str(await feedback_result)
                return str(feedback_result)
            return flow_instance._request_human_feedback(
                message=message,
                output=method_output,
                metadata=metadata,
                emit=emit,
            )

        def _process_feedback(
            flow_instance: Flow[Any],
            method_output: Any,
            raw_feedback: str,
        ) -> HumanFeedbackResult | str:
            collapsed_outcome: str | None = None

            if not raw_feedback.strip():
                if default_outcome:
                    collapsed_outcome = default_outcome
                elif emit:
                    collapsed_outcome = emit[0]
            elif emit:
                if llm is not None:
                    collapsed_outcome = flow_instance._collapse_to_outcome(
                        feedback=raw_feedback,
                        outcomes=emit,
                        llm=llm,
                    )
                else:
                    collapsed_outcome = emit[0]

            result = HumanFeedbackResult(
                output=method_output,
                feedback=raw_feedback,
                outcome=collapsed_outcome,
                timestamp=datetime.now(),
                method_name=func.__name__,
                metadata=metadata or {},
            )

            flow_instance.human_feedback_history.append(result)
            flow_instance.last_human_feedback = result

            if emit:
                if collapsed_outcome is None:
                    collapsed_outcome = default_outcome or emit[0]
                    result.outcome = collapsed_outcome
                return collapsed_outcome
            return result

        if asyncio.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(self: Flow[Any], *args: Any, **kwargs: Any) -> Any:
                method_output = await func(self, *args, **kwargs)

                if learn and getattr(self, "memory", None) is not None:
                    method_output = _pre_review_with_lessons(self, method_output)

                raw_feedback = await _request_feedback_async(self, method_output)
                result = _process_feedback(self, method_output, raw_feedback)

                if (
                    learn
                    and getattr(self, "memory", None) is not None
                    and raw_feedback.strip()
                ):
                    _distill_and_store_lessons(self, method_output, raw_feedback)

                # Stash the real method output for final flow result when emit is set:
                # result is the collapsed outcome string for routing, but we preserve the
                # actual method output as the flow's final result. Uses per-method dict for
                # concurrency safety and to handle None returns.
                if emit:
                    self._human_feedback_method_outputs[func.__name__] = method_output

                return result

            wrapper: Any = async_wrapper
        else:

            @wraps(func)
            def sync_wrapper(self: Flow[Any], *args: Any, **kwargs: Any) -> Any:
                method_output = func(self, *args, **kwargs)

                if learn and getattr(self, "memory", None) is not None:
                    method_output = _pre_review_with_lessons(self, method_output)

                raw_feedback = _request_feedback(self, method_output)
                result = _process_feedback(self, method_output, raw_feedback)

                if (
                    learn
                    and getattr(self, "memory", None) is not None
                    and raw_feedback.strip()
                ):
                    _distill_and_store_lessons(self, method_output, raw_feedback)

                # Stash the real method output for final flow result when emit is set:
                # result is the collapsed outcome string for routing, but we preserve the
                # actual method output as the flow's final result. Uses per-method dict for
                # concurrency safety and to handle None returns.
                if emit:
                    self._human_feedback_method_outputs[func.__name__] = method_output

                return result

            wrapper = sync_wrapper

        return wrapper  # type: ignore[no-any-return]

    return decorator


def human_feedback(
    message: str,
    emit: Sequence[str] | None = None,
    llm: str | BaseLLM | None = "gpt-4o-mini",
    default_outcome: str | None = None,
    metadata: dict[str, Any] | None = None,
    provider: HumanFeedbackProvider | None = None,
    learn: bool = False,
    learn_source: str = "hitl",
    learn_strict: bool = False,
) -> Callable[[F], F]:
    """Compatibility import path for the Flow human-feedback DSL decorator."""
    from crewai.flow.dsl._human_feedback import human_feedback as dsl_human_feedback

    return dsl_human_feedback(
        message=message,
        emit=emit,
        llm=llm,
        default_outcome=default_outcome,
        metadata=metadata,
        provider=provider,
        learn=learn,
        learn_source=learn_source,
        learn_strict=learn_strict,
    )
