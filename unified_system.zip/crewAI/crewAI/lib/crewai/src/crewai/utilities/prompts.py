"""Prompt generation and management utilities for CrewAI agents."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from crewai.utilities.i18n import I18N_DEFAULT


class StandardPromptResult(BaseModel):
    """Result with only prompt field for standard mode."""

    prompt: str = Field(default="")

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def __contains__(self, key: str) -> bool:
        return hasattr(self, key) and getattr(self, key) is not None


class SystemPromptResult(StandardPromptResult):
    """Result with system, user, and prompt fields for system prompt mode."""

    system: str = Field(default="")
    user: str = Field(default="")


COMPONENTS = Literal[
    "role_playing",
    "tools",
    "no_tools",
    "native_tools",
    "task",
    "native_task",
    "task_no_tools",
]


class Prompts(BaseModel):
    """Manages and generates prompts for a generic agent.

    Notes:
        - Need to refactor so that prompt is not tightly coupled to agent.
    """

    has_tools: bool = Field(
        default=False, description="Indicates if the agent has access to tools"
    )
    use_native_tool_calling: bool = Field(
        default=False,
        description="Whether to use native function calling instead of ReAct format",
    )
    system_template: str | None = Field(
        default=None, description="Custom system prompt template"
    )
    prompt_template: str | None = Field(
        default=None, description="Custom user prompt template"
    )
    response_template: str | None = Field(
        default=None, description="Custom response prompt template"
    )
    use_system_prompt: bool = Field(
        default=False,
        description="Whether to use the system prompt when no custom templates are provided",
    )
    agent: Any = Field(description="Reference to the agent using these prompts")

    def task_execution(self) -> SystemPromptResult | StandardPromptResult:
        """Generate a standard prompt for task execution.

        Returns:
            A dictionary containing the constructed prompt(s).
        """
        slices: list[COMPONENTS] = ["role_playing"]
        if self.has_tools:
            if not self.use_native_tool_calling:
                slices.append("tools")
        else:
            slices.append("no_tools")
        system: str = self._build_prompt(slices) + self._build_skill_block()

        task_slice: COMPONENTS
        if self.use_native_tool_calling:
            task_slice = "native_task"
        elif self.has_tools:
            task_slice = "task"
        else:
            task_slice = "task_no_tools"
        slices.append(task_slice)

        if (
            not self.system_template
            and not self.prompt_template
            and self.use_system_prompt
        ):
            return SystemPromptResult(
                system=system,
                user=self._build_prompt([task_slice]),
                prompt=self._build_prompt(slices) + self._build_skill_block(),
            )
        return StandardPromptResult(
            prompt=self._build_prompt(
                slices,
                self.system_template,
                self.prompt_template,
                self.response_template,
            )
            + self._build_skill_block()
        )

    def _build_skill_block(self) -> str:
        """Render the agent's activated skills as a stable XML block.

        Skills are agent-scoped (do not change per task), so they live in the
        system prompt where prompt-cache prefixes can survive across calls.
        """
        skills = getattr(self.agent, "skills", None)
        if not skills:
            return ""

        from crewai.skills.loader import format_skill_context
        from crewai.skills.models import Skill

        sections = [format_skill_context(s) for s in skills if isinstance(s, Skill)]
        if not sections:
            return ""
        return "\n\n<skills>\n" + "\n\n".join(sections) + "\n</skills>"

    def _build_prompt(
        self,
        components: list[COMPONENTS],
        system_template: str | None = None,
        prompt_template: str | None = None,
        response_template: str | None = None,
    ) -> str:
        """Constructs a prompt string from specified components.

        Args:
            components: List of component names to include in the prompt.
            system_template: Optional custom template for the system prompt.
            prompt_template: Optional custom template for the user prompt.
            response_template: Optional custom template for the response prompt.

        Returns:
            The constructed prompt string.
        """
        prompt: str
        if not system_template or not prompt_template:
            prompt_parts: list[str] = [
                I18N_DEFAULT.slice(component) for component in components
            ]
            prompt = "".join(prompt_parts)
        else:
            template_parts: list[str] = [
                I18N_DEFAULT.slice(component)
                for component in components
                if component != "task"
            ]
            system: str = system_template.replace(
                "{{ .System }}", "".join(template_parts)
            )
            prompt = prompt_template.replace(
                "{{ .Prompt }}", "".join(I18N_DEFAULT.slice("task"))
            )
            if response_template:
                response: str = response_template.split("{{ .Response }}")[0]
                prompt = f"{system}\n{prompt}\n{response}"
            else:
                prompt = f"{system}\n{prompt}"

        return (
            prompt.replace("{goal}", self.agent.goal)
            .replace("{role}", self.agent.role)
            .replace("{backstory}", self.agent.backstory)
        )
