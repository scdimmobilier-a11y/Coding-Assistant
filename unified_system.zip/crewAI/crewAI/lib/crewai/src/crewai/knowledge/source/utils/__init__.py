"""Knowledge source utilities."""
